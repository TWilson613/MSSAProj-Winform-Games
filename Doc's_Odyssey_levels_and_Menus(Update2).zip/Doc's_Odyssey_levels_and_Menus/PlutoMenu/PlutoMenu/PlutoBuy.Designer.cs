﻿
namespace PlutoMenu
{
    partial class PlutoBuy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlutoBuy));
            this.lblBuy = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnClocktower = new System.Windows.Forms.Button();
            this.btnPanel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBuy
            // 
            this.lblBuy.AutoSize = true;
            this.lblBuy.BackColor = System.Drawing.Color.Transparent;
            this.lblBuy.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuy.ForeColor = System.Drawing.Color.Yellow;
            this.lblBuy.Location = new System.Drawing.Point(254, 200);
            this.lblBuy.Name = "lblBuy";
            this.lblBuy.Size = new System.Drawing.Size(774, 64);
            this.lblBuy.TabIndex = 1;
            this.lblBuy.Text = "What items would you like to buy?";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnClocktower
            // 
            this.btnClocktower.BackColor = System.Drawing.Color.Transparent;
            this.btnClocktower.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClocktower.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClocktower.ForeColor = System.Drawing.Color.Yellow;
            this.btnClocktower.Location = new System.Drawing.Point(432, 637);
            this.btnClocktower.Margin = new System.Windows.Forms.Padding(5);
            this.btnClocktower.Name = "btnClocktower";
            this.btnClocktower.Size = new System.Drawing.Size(387, 65);
            this.btnClocktower.TabIndex = 6;
            this.btnClocktower.Text = "Clocktower Replica";
            this.btnClocktower.UseVisualStyleBackColor = false;
            this.btnClocktower.Click += new System.EventHandler(this.btnClocktower_Click);
            // 
            // btnPanel
            // 
            this.btnPanel.BackColor = System.Drawing.Color.Transparent;
            this.btnPanel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPanel.ForeColor = System.Drawing.Color.Yellow;
            this.btnPanel.Location = new System.Drawing.Point(432, 550);
            this.btnPanel.Margin = new System.Windows.Forms.Padding(5);
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.Size = new System.Drawing.Size(387, 65);
            this.btnPanel.TabIndex = 5;
            this.btnPanel.Text = "Control Panel";
            this.btnPanel.UseVisualStyleBackColor = false;
            this.btnPanel.Click += new System.EventHandler(this.btnPanel_Click);
            // 
            // PlutoBuy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClocktower);
            this.Controls.Add(this.btnPanel);
            this.Controls.Add(this.lblBuy);
            this.Name = "PlutoBuy";
            this.Text = "PlutoBuy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBuy;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnClocktower;
        private System.Windows.Forms.Button btnPanel;
    }
}