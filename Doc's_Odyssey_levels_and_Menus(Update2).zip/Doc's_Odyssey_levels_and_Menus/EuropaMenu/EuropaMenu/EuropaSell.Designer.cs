﻿
namespace EuropaMenu
{
    partial class EuropaSell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EuropaSell));
            this.lblPrompt = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnHelmet = new System.Windows.Forms.Button();
            this.btnHat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrompt
            // 
            this.lblPrompt.AutoSize = true;
            this.lblPrompt.BackColor = System.Drawing.Color.Transparent;
            this.lblPrompt.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrompt.ForeColor = System.Drawing.Color.Yellow;
            this.lblPrompt.Location = new System.Drawing.Point(254, 200);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(763, 64);
            this.lblPrompt.TabIndex = 3;
            this.lblPrompt.Text = "What items would you like to sell?";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 10;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnHelmet
            // 
            this.btnHelmet.BackColor = System.Drawing.Color.Transparent;
            this.btnHelmet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHelmet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelmet.ForeColor = System.Drawing.Color.Yellow;
            this.btnHelmet.Location = new System.Drawing.Point(432, 637);
            this.btnHelmet.Margin = new System.Windows.Forms.Padding(5);
            this.btnHelmet.Name = "btnHelmet";
            this.btnHelmet.Size = new System.Drawing.Size(387, 65);
            this.btnHelmet.TabIndex = 9;
            this.btnHelmet.Text = "Mind Reading Helmet";
            this.btnHelmet.UseVisualStyleBackColor = false;
            this.btnHelmet.Click += new System.EventHandler(this.btnHelmet_Click);
            // 
            // btnHat
            // 
            this.btnHat.BackColor = System.Drawing.Color.Transparent;
            this.btnHat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHat.ForeColor = System.Drawing.Color.Yellow;
            this.btnHat.Location = new System.Drawing.Point(432, 550);
            this.btnHat.Margin = new System.Windows.Forms.Padding(5);
            this.btnHat.Name = "btnHat";
            this.btnHat.Size = new System.Drawing.Size(387, 65);
            this.btnHat.TabIndex = 8;
            this.btnHat.Text = "Marty\'s Hat";
            this.btnHat.UseVisualStyleBackColor = false;
            this.btnHat.Click += new System.EventHandler(this.btnHat_Click);
            // 
            // EuropaSell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnHelmet);
            this.Controls.Add(this.btnHat);
            this.Controls.Add(this.lblPrompt);
            this.Name = "EuropaSell";
            this.Text = "EuropaSell";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnHelmet;
        private System.Windows.Forms.Button btnHat;
    }
}