﻿
namespace EuropaMenu
{
    partial class lblBuy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(lblBuy));
            this.lblPrompt = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnOutatime = new System.Windows.Forms.Button();
            this.btnLightning = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrompt
            // 
            this.lblPrompt.AutoSize = true;
            this.lblPrompt.BackColor = System.Drawing.Color.Transparent;
            this.lblPrompt.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrompt.ForeColor = System.Drawing.Color.Yellow;
            this.lblPrompt.Location = new System.Drawing.Point(254, 200);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(774, 64);
            this.lblPrompt.TabIndex = 2;
            this.lblPrompt.Text = "What items would you like to buy?";
            this.lblPrompt.Click += new System.EventHandler(this.lblPrompt_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnOutatime
            // 
            this.btnOutatime.BackColor = System.Drawing.Color.Transparent;
            this.btnOutatime.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOutatime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOutatime.ForeColor = System.Drawing.Color.Yellow;
            this.btnOutatime.Location = new System.Drawing.Point(432, 637);
            this.btnOutatime.Margin = new System.Windows.Forms.Padding(5);
            this.btnOutatime.Name = "btnOutatime";
            this.btnOutatime.Size = new System.Drawing.Size(387, 65);
            this.btnOutatime.TabIndex = 6;
            this.btnOutatime.Text = "OUTATIME License Plate";
            this.btnOutatime.UseVisualStyleBackColor = false;
            this.btnOutatime.Click += new System.EventHandler(this.btnOutatime_Click);
            // 
            // btnLightning
            // 
            this.btnLightning.BackColor = System.Drawing.Color.Transparent;
            this.btnLightning.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLightning.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLightning.ForeColor = System.Drawing.Color.Yellow;
            this.btnLightning.Location = new System.Drawing.Point(432, 550);
            this.btnLightning.Margin = new System.Windows.Forms.Padding(5);
            this.btnLightning.Name = "btnLightning";
            this.btnLightning.Size = new System.Drawing.Size(387, 65);
            this.btnLightning.TabIndex = 5;
            this.btnLightning.Text = "Lightning in a Bottle";
            this.btnLightning.UseVisualStyleBackColor = false;
            this.btnLightning.Click += new System.EventHandler(this.btnLightning_Click);
            // 
            // lblBuy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnOutatime);
            this.Controls.Add(this.btnLightning);
            this.Controls.Add(this.lblPrompt);
            this.Name = "lblBuy";
            this.Text = "EuropaBuy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnOutatime;
        private System.Windows.Forms.Button btnLightning;
    }
}