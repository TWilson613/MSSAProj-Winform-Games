﻿
namespace MarsMenu
{
    partial class BuyMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuyMenu));
            this.buyPrompt = new System.Windows.Forms.Label();
            this.btnWalkman = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnPlutonium = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buyPrompt
            // 
            this.buyPrompt.AutoSize = true;
            this.buyPrompt.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buyPrompt.ForeColor = System.Drawing.Color.Yellow;
            this.buyPrompt.Location = new System.Drawing.Point(254, 200);
            this.buyPrompt.Margin = new System.Windows.Forms.Padding(5);
            this.buyPrompt.Name = "buyPrompt";
            this.buyPrompt.Size = new System.Drawing.Size(774, 64);
            this.buyPrompt.TabIndex = 0;
            this.buyPrompt.Text = "What items would you like to buy?";
            // 
            // btnWalkman
            // 
            this.btnWalkman.BackColor = System.Drawing.Color.Transparent;
            this.btnWalkman.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWalkman.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWalkman.ForeColor = System.Drawing.Color.Yellow;
            this.btnWalkman.Location = new System.Drawing.Point(432, 637);
            this.btnWalkman.Margin = new System.Windows.Forms.Padding(5);
            this.btnWalkman.Name = "btnWalkman";
            this.btnWalkman.Size = new System.Drawing.Size(387, 65);
            this.btnWalkman.TabIndex = 7;
            this.btnWalkman.Text = "Walkman";
            this.btnWalkman.UseVisualStyleBackColor = false;
            this.btnWalkman.Click += new System.EventHandler(this.btnWalkman_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 6;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnPlutonium
            // 
            this.btnPlutonium.BackColor = System.Drawing.Color.Transparent;
            this.btnPlutonium.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPlutonium.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlutonium.ForeColor = System.Drawing.Color.Yellow;
            this.btnPlutonium.Location = new System.Drawing.Point(432, 550);
            this.btnPlutonium.Margin = new System.Windows.Forms.Padding(5);
            this.btnPlutonium.Name = "btnPlutonium";
            this.btnPlutonium.Size = new System.Drawing.Size(387, 65);
            this.btnPlutonium.TabIndex = 5;
            this.btnPlutonium.Text = "Plutonium";
            this.btnPlutonium.UseVisualStyleBackColor = false;
            this.btnPlutonium.Click += new System.EventHandler(this.btnPlutonium_Click);
            // 
            // BuyMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnWalkman);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnPlutonium);
            this.Controls.Add(this.buyPrompt);
            this.Name = "BuyMenu";
            this.Text = "BuyMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label buyPrompt;
        private System.Windows.Forms.Button btnWalkman;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnPlutonium;
    }
}