﻿
namespace PlutoMenu
{
    partial class PlutoSell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlutoSell));
            this.lblSell = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnJacket = new System.Windows.Forms.Button();
            this.btnVest = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSell
            // 
            this.lblSell.AutoSize = true;
            this.lblSell.BackColor = System.Drawing.Color.Transparent;
            this.lblSell.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSell.ForeColor = System.Drawing.Color.Yellow;
            this.lblSell.Location = new System.Drawing.Point(254, 200);
            this.lblSell.Name = "lblSell";
            this.lblSell.Size = new System.Drawing.Size(763, 64);
            this.lblSell.TabIndex = 2;
            this.lblSell.Text = "What items would you like to sell?";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 10;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnJacket
            // 
            this.btnJacket.BackColor = System.Drawing.Color.Transparent;
            this.btnJacket.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJacket.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJacket.ForeColor = System.Drawing.Color.Yellow;
            this.btnJacket.Location = new System.Drawing.Point(432, 637);
            this.btnJacket.Margin = new System.Windows.Forms.Padding(5);
            this.btnJacket.Name = "btnJacket";
            this.btnJacket.Size = new System.Drawing.Size(387, 65);
            this.btnJacket.TabIndex = 9;
            this.btnJacket.Text = "Marty\'s Jacket";
            this.btnJacket.UseVisualStyleBackColor = false;
            this.btnJacket.Click += new System.EventHandler(this.btnJacket_Click);
            // 
            // btnVest
            // 
            this.btnVest.BackColor = System.Drawing.Color.Transparent;
            this.btnVest.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVest.ForeColor = System.Drawing.Color.Yellow;
            this.btnVest.Location = new System.Drawing.Point(432, 550);
            this.btnVest.Margin = new System.Windows.Forms.Padding(5);
            this.btnVest.Name = "btnVest";
            this.btnVest.Size = new System.Drawing.Size(387, 65);
            this.btnVest.TabIndex = 8;
            this.btnVest.Text = "Marty\'s Vest";
            this.btnVest.UseVisualStyleBackColor = false;
            this.btnVest.Click += new System.EventHandler(this.btnVest_Click);
            // 
            // PlutoSell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnJacket);
            this.Controls.Add(this.btnVest);
            this.Controls.Add(this.lblSell);
            this.Name = "PlutoSell";
            this.Text = "PlutoSell";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSell;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnJacket;
        private System.Windows.Forms.Button btnVest;
    }
}