﻿using System;
using System.IO;

namespace TaskTrackingLibrary
{
    public class MainMethods
    {
        public static void FolderCreation() //ensures the folder exists to create the text file inside.
        {
            string TestFolder = @"c:\Users\Public\TestFolder";
            if (System.IO.Directory.Exists(TestFolder))
            {
                return;
            }
            else
            {
                System.IO.Directory.CreateDirectory(TestFolder);
                return;
            }

        }
    
        string[] TextLines = {};
        public static bool MainMenu(string[] Text)
        {
            Console.Clear(); //Comment out if wish to see previous data 
            Console.WriteLine("Choose a Team Member");
            Console.WriteLine("1) Trent");
            Console.WriteLine("2) Derek");
            Console.WriteLine("3) Cerrell");
            Console.WriteLine("4) Tony");
            Console.WriteLine("5) Gary");
            Console.WriteLine("6) Exit");
            Console.Write("\r\nSelect an option: ");

            switch (Console.ReadLine()) //creates menu board for Console. 
            {
                case "1": //link to edit String Trent
                   Text = TaskCompletion("1", Text);
                    return true;
                case "2": //link to edit string Derek
                    Text = TaskCompletion("2", Text);
                    return true;
                case "3":
                    Text = TaskCompletion("3", Text);
                    return true;
                case "4":
                    Text = TaskCompletion("4", Text);
                    return true;
                case "5":
                    Text = TaskCompletion("5", Text);
                    return true;
                case "6":
                    //ends program and creates text file. Inputting all the string array for each person's "tasks" into txt file. 
                     System.IO.File.WriteAllLines(@"C:\Users\Public\TestFolder\TeamLog.txt", Text);
                    return false;
                default:
                    return true;
            }

        

           
            string[] TaskCompletion(string ID, string[] Data) //pass perameter for Employee id here to identify the person "Line associated per person"
            {
                Console.WriteLine($"Please Select if your task is complete.");
                Console.WriteLine("1) If Complete.");
                Console.WriteLine("2) If Incomplete.");
                switch (Console.ReadLine())
                {
                    case "1":

                        int colon = Data[int.Parse(ID) - 1].IndexOf(':');
                        int tac = Data[int.Parse(ID) - 1].IndexOf('-');
                        string name = Data[int.Parse(ID) - 1].Substring(colon + 1, tac -1);
                        //this block creates substring for editing the Txt file per line to ensure correct persons data line is edited. 
                        Console.WriteLine($"{name} has completed this task");
                         Data[int.Parse(ID) - 1] = Data[int.Parse(ID) - 1].Replace("Pending", "has completed this task");
                        return Data;
                    case "2":
                       string reason = Reason();
                        Data[int.Parse(ID) - 1] = Data[int.Parse(ID) - 1].Replace("Pending", $"{reason}");
                        Console.WriteLine($"{Data[int.Parse(ID) - 1]}");
                        return Data;
                    default:
                        return Data;
                }
            }
            static string Reason()
            {
               Console.Clear(); //comment this out to test if program is giving correct console output prior to exiting. 
                Console.WriteLine("Input why your task is  not complete and a date for completion");//have you completed the tasks?
                string text3;
                text3 = (CaptureInput());
               DisplayResult(text3);
                return text3;
            }
            //these next two methods are used just for simplicity within Method Reason. Pulls user input/displays 
         static void DisplayResult(string message)
            {
                Console.WriteLine($"\r\nYour Reason for incompletion is: {message}");
                Console.Write("\r\nPress Enter to return to Main Menu");
                Console.ReadLine();
            }
          static string CaptureInput()
            {
                Console.Write("Enter the reason for incompletion and the date/time of estimated completion: ");
                return Console.ReadLine();
            } }
    }
}
