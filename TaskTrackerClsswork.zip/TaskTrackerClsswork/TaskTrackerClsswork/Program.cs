﻿using System;
namespace TaskTrackerClsswork
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //    bool showMenu = true;
            //    while (showMenu)
            //    {
            //        showMenu = MainMenu();
            //    }
            //}
            //private static bool MainMenu()
            //{
            //    Console.Clear();
            //    Console.WriteLine("Choose a Team Member");
            //    Console.WriteLine("1) Trent");
            //    Console.WriteLine("2) Derek");
            //    Console.WriteLine("3) Cerrell");
            //    Console.WriteLine("4) Tony");
            //    Console.WriteLine("5) Gary");
            //    Console.WriteLine("6) Exit");
            //    Console.Write("\r\nSelect an option: ");
            //    System.IO.File.Create(@"C:\Users\Public\TestFolder\TeamLog.txt");
            //    string T = "Trent", D = "Derek", C = "Cerrell", TO = "Tony" , G = "Gary";

            //    switch (Console.ReadLine())
            //    {
            //        case "1":
            //            TaskCompletion();
            //            return true;
            //        case "2":
            //            TaskCompletion();
            //            //System.IO.File.Create(@"C:\Users\Public\TestFolder\DerekStatus.txt");
            //            return true;
            //        case "3":
            //            TaskCompletion();
            //            //System.IO.File.Create(@"C:\Users\Public\TestFolder\CerrellStatus.txt");
            //            return true;
            //        case "4":
            //            TaskCompletion();
            //            //System.IO.File.Create(@"C:\Users\Public\TestFolder\TonyStatus.txt");
            //            return true;
            //        case "5":
            //            TaskCompletion();
            //           // System.IO.File.Create(@"C:\Users\Public\TestFolder\GaryStatus.txt");
            //            return true;
            //        case "6":
            //            return false;
            //        default:
            //            return true;
            //    }

            //     static string CaptureInput()
            //    {
            //        Console.Write("Enter the reason for incompletion and the date/time of estimated completion: ");
            //        return Console.ReadLine();
            //    }

            //     static void Reason()
            //    {
            //        Console.Clear();
            //        Console.WriteLine("Input why your task is  not complete and a date for completion");//have you completed the tasks?
            //        string text;
            //        text = (CaptureInput());
            //        System.IO.File.WriteAllText(@"C:\Users\Public\TestFolder\ReasonForIncompletion.txt",text);


            //        DisplayResult(text);
            //    }

            //     static void DisplayResult(string message)
            //    {
            //        Console.WriteLine($"\r\nYour Reason for incompletion is: {message}");
            //        Console.Write("\r\nPress Enter to return to Main Menu");
            //        Console.ReadLine();
            //    }
            // bool TaskCompletion()
            //    {
            //        Console.WriteLine($"Please Select if your task is complete.");
            //        Console.WriteLine("1) If Complete.");
            //        Console.WriteLine("2) If Incomplete.");
            //        switch (Console.ReadLine())
            //        {
            //            case "1":
            //                return false;
            //            case "2":
            //                Reason();
            //                return true;
            //            default:
            //                return true;
            //        }
            //    }
            //}
        }
}
