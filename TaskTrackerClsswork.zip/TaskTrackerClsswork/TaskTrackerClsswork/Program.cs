﻿using System;
using TaskTrackingLibrary;
namespace TaskTrackerClsswork
{
    class Program
    {
        static void Main(string[] args)
        {
            MainMethods.FolderCreation(); //This will check to make sure the Folder is available on the computer
         
            string Trent, Derek, Gary, Cerrell, Tony;
            Trent = "Employee: Trent - Pending";
            Derek = "Employee: Derek - Pending";
            Cerrell = "Employee: Cerrell - Pending";
            Tony = "Employee: Tony - Pending";
            Gary = "Employee: Gary - Pending";
            string[] TextLines = { Trent, Derek, Cerrell, Tony, Gary };
            bool showMenu = true;
            while (showMenu) //holds menu open until prompted to end program
            {
                showMenu = MainMethods.MainMenu(TextLines); // all menu aspects - see MainMethods page for info
            }
        }

    }
}

//1st. need an array for the "strings" 
//2: Edit each part of array depending on first menu
//3: Pass "ID of person" to identify which String on the array
//4: end of menu be "save data" / print the strings with file string