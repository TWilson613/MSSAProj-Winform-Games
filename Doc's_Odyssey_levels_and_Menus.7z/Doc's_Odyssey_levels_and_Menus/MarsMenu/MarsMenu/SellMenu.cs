﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsMenu
{
    public partial class SellMenu : Form
    {
        public SellMenu()
        {
            InitializeComponent();
        }

        private void btnPeacemaker_Click(object sender, EventArgs e)
        {

        }

        private void btnGuitar_Click(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {

        }
    }
}
