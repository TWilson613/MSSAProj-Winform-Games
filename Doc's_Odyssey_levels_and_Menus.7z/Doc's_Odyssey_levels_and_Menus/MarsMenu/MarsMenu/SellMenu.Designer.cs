﻿
namespace MarsMenu
{
    partial class SellMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellMenu));
            this.lblSell = new System.Windows.Forms.Label();
            this.btnGuitar = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnPeacemaker = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSell
            // 
            this.lblSell.AutoSize = true;
            this.lblSell.BackColor = System.Drawing.Color.Black;
            this.lblSell.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSell.ForeColor = System.Drawing.Color.Yellow;
            this.lblSell.Location = new System.Drawing.Point(254, 200);
            this.lblSell.Name = "lblSell";
            this.lblSell.Size = new System.Drawing.Size(763, 64);
            this.lblSell.TabIndex = 0;
            this.lblSell.Text = "What items would you like to sell?";
            // 
            // btnGuitar
            // 
            this.btnGuitar.BackColor = System.Drawing.Color.Transparent;
            this.btnGuitar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuitar.ForeColor = System.Drawing.Color.Yellow;
            this.btnGuitar.Location = new System.Drawing.Point(432, 637);
            this.btnGuitar.Margin = new System.Windows.Forms.Padding(5);
            this.btnGuitar.Name = "btnGuitar";
            this.btnGuitar.Size = new System.Drawing.Size(387, 65);
            this.btnGuitar.TabIndex = 10;
            this.btnGuitar.Text = "Marty\'s Guitar";
            this.btnGuitar.UseVisualStyleBackColor = false;
            this.btnGuitar.Click += new System.EventHandler(this.btnGuitar_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(387, 65);
            this.btnReturn.TabIndex = 9;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnPeacemaker
            // 
            this.btnPeacemaker.BackColor = System.Drawing.Color.Transparent;
            this.btnPeacemaker.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPeacemaker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPeacemaker.ForeColor = System.Drawing.Color.Yellow;
            this.btnPeacemaker.Location = new System.Drawing.Point(432, 550);
            this.btnPeacemaker.Margin = new System.Windows.Forms.Padding(5);
            this.btnPeacemaker.Name = "btnPeacemaker";
            this.btnPeacemaker.Size = new System.Drawing.Size(387, 65);
            this.btnPeacemaker.TabIndex = 8;
            this.btnPeacemaker.Text = "Colt Peacemaker";
            this.btnPeacemaker.UseVisualStyleBackColor = false;
            this.btnPeacemaker.Click += new System.EventHandler(this.btnPeacemaker_Click);
            // 
            // SellMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnGuitar);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnPeacemaker);
            this.Controls.Add(this.lblSell);
            this.Name = "SellMenu";
            this.Text = "SellMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSell;
        private System.Windows.Forms.Button btnGuitar;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnPeacemaker;
    }
}