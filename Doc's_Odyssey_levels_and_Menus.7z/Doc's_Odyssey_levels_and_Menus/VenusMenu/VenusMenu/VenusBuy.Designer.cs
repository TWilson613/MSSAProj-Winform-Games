﻿
namespace VenusMenu
{
    partial class VenusBuy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VenusBuy));
            this.lblBuy = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAlmanac = new System.Windows.Forms.Button();
            this.btnFuel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBuy
            // 
            this.lblBuy.AutoSize = true;
            this.lblBuy.BackColor = System.Drawing.Color.Transparent;
            this.lblBuy.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuy.ForeColor = System.Drawing.Color.Yellow;
            this.lblBuy.Location = new System.Drawing.Point(254, 200);
            this.lblBuy.Name = "lblBuy";
            this.lblBuy.Size = new System.Drawing.Size(774, 64);
            this.lblBuy.TabIndex = 0;
            this.lblBuy.Text = "What items would you like to buy?";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Yellow;
            this.btnReturn.Location = new System.Drawing.Point(432, 729);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(354, 91);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAlmanac
            // 
            this.btnAlmanac.BackColor = System.Drawing.Color.Transparent;
            this.btnAlmanac.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAlmanac.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlmanac.ForeColor = System.Drawing.Color.Yellow;
            this.btnAlmanac.Location = new System.Drawing.Point(432, 637);
            this.btnAlmanac.Margin = new System.Windows.Forms.Padding(5);
            this.btnAlmanac.Name = "btnAlmanac";
            this.btnAlmanac.Size = new System.Drawing.Size(354, 91);
            this.btnAlmanac.TabIndex = 6;
            this.btnAlmanac.Text = "Almanac";
            this.btnAlmanac.UseVisualStyleBackColor = false;
            this.btnAlmanac.Click += new System.EventHandler(this.btnAlmanac_Click);
            // 
            // btnFuel
            // 
            this.btnFuel.BackColor = System.Drawing.Color.Transparent;
            this.btnFuel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFuel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFuel.ForeColor = System.Drawing.Color.Yellow;
            this.btnFuel.Location = new System.Drawing.Point(432, 550);
            this.btnFuel.Margin = new System.Windows.Forms.Padding(5);
            this.btnFuel.Name = "btnFuel";
            this.btnFuel.Size = new System.Drawing.Size(354, 91);
            this.btnFuel.TabIndex = 5;
            this.btnFuel.Text = "Fuel";
            this.btnFuel.UseVisualStyleBackColor = false;
            this.btnFuel.Click += new System.EventHandler(this.btnFuel_Click);
            // 
            // VenusBuy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1281, 1002);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnAlmanac);
            this.Controls.Add(this.btnFuel);
            this.Controls.Add(this.lblBuy);
            this.Name = "VenusBuy";
            this.Text = "VenusBuy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBuy;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAlmanac;
        private System.Windows.Forms.Button btnFuel;
    }
}