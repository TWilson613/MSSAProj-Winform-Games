﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VenusMenu
{
    public partial class VenusSell : Form
    {
        public VenusSell()
        {
            InitializeComponent();
        }

        private void btnLabCoat_Click(object sender, EventArgs e)
        {

        }

        private void btnHoverboard_Click(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {

        }
    }
}
