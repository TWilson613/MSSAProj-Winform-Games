﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Level2;
using DocsOdyssey;
using Level3;

namespace MainMenuApp
{
    public partial class MenuPage : Form
    {
        public MenuPage()
        {

            InitializeComponent();

        }

        private void Level2Button_Click(object sender, EventArgs e)
        {
            
            new Level2.Level2().Show();

        }

        private void Level3_Click(object sender, EventArgs e)
        {
            new Level3.Level3().Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            new Level1().Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            new Level4.Level4().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Level5.Level5().Show();
        }
    }
}
